#include <iostream>
using namespace std;

int primo_o_no(int numero);

int main() {
    int num, primo, mayor, x;
    
    cout<<"Ingrese números enteros, ingrese 0 para terminar: ";
    cin>>num;
    
    primo=0;
    mayor=0;
    x=primo_o_no(num);
    
    if(x==0){
        primo=num;
    }
    
    if(num!=0){
        while (true){
        cout<<"Ingrese números enteros, ingrese 0 para terminar: ";
        cin>>num;
        
        if(num==0){
            break;
        }
        
        x=primo_o_no(num);
        
        if(x==0){
            mayor=num;
        }
        
        if(mayor>primo){
            primo=mayor;
        }
        
        }
        
        if(primo==1 or primo<=0){
            cout<<"No ingresaste números primos :c";
        }else{
            cout<<"El mayor número primo ingresado es: "<<primo;
        }
    }else{
        cout<<"No ingresaste números :c";
    }
    
    return 0;
}

int primo_o_no(int numero){
    int flag;
    flag=0;
    for(int i=2;i<numero;i++){
        if(numero%i==0){
            flag=1;
        }
    }
    return flag;
}
