----------------------------------------------------------------------------SUMATORIA PARES-----------------------------------------------------------------------------

#include <iostream>
using namespace std;

int main() {
    int suma1, suma2;
    suma2=0;

    int vector[10];
    
    for(int i=0; i<10; i++){
        vector[i]=i;
    }
    
    for(int i=0; i<10; i++){
        if(vector[i]%2==0){
            suma1=vector[i];
            suma2+=suma1;
        }
    }
    
    cout<<"la sumatoria es:"<<suma2;
    return 0;
}

----------------------------------------------------------------------------------------?-------------------------------------------------------------------------------
#include <iostream>
using namespace std;

int main() {

    int vector[10];
    int x;
    
    for(int i=0; i<10; i++){
        vector[i]=rand();
    }
    
    for(int i=0; i<8; i++){
        vector[i+1]=x;
        if(x<vector[i]){
            vector[i]=x;
        }if(x>vector[i+2]){
            vector[i+2]=x;
        }
    }
    for(int i=0; i<10; i++){
        cout<<vector[i]<<endl;
    }

    return 0;
}

--------------------------------------------------------------------------------INSERTAR O EIMINAR----------------------------------------------------------------------

void insertar(int *v, int n, int x, int pos){
    for(int i=n; i>pos; i--){
    v[i]=v[i-1]
    }
    v[pos]=x;
}

void eliminar(int *v, int n, int pos){
    for(int i=pos; i<n-1; i++){
    v[i]=v[i+1]
    {
}

----------------------------------------------------------------------------------PRODUCTO PUNTO------------------------------------------------------------------------

#include <iostream>
using namespace std;

int producto_punto(int* v1,int* v2,int tam){
    int cont=0;
    int mult=0;
    for(int i=0; i<tam; i++){
        mult=v1[i]*v2[i];
        cont+=mult;
   }
   return cont;
}

int main(){
   int vectora[3];
   int vectorb[3];
   int result=0;
   
   for(int i=0; i<3; i++){
       vectora[i]=i;
       vectorb[i]=i+1;
   }
   
   result=producto_punto(vectora, vectorb, 3);
   
   cout<<"el producto punto es: "<<result;
   
   return 0;
}
    
---------------------------------------------------------------------------------PRODUCTO CRUZ--------------------------------------------------------------------------
    #include <iostream>
using namespace std;

void producto_cruz(int* v1,int* v2, int* v3){
    int a=0;
    int b=0;
    int c=0;
    
    a=(v1[1]*v2[2])-(v1[2]*v2[1]);
    b=(v1[2]*v2[0])-(v1[0]*v2[2]);
    c=(v1[0]*v2[1])-(v1[1]*v2[0]);
    
    v3[0]=a;
    v3[1]=b;
    v3[2]=c;
}

int main(){
   int vectora[3];
   int vectorb[3];
   int vect_final[3];

    vectora[0]=3;
    vectora[1]=0;
    vectora[2]=2;
    
    vectorb[0]=-1;
    vectorb[1]=4;
    vectorb[2]=2;
    
    producto_cruz(vectora, vectorb, vect_final);
   
   cout<<"El producto cruz es: "<<vect_final[0]<<","<<vect_final[1]<<","<<vect_final[2];
   
   return 0;
   
}
    
-----------------------------------------------------------------------------------MATRIZ*VECTOR------------------------------------------------------------------------
    
#include <iostream>
#include <stdlib.h>
using namespace std;

void matriz_por_vector(int** m, int* v, int* r, int filas, int columnas){ //Función matriz * vector
    for(int i=0; i<filas; i++){
        int cont=0;
        for(int j=0; j<columnas; j++){
            cont+=m[i][j]*v[j];
        }
    r[i]=cont;    
    }
}

int main(){
    int **matriz, nFilas=3, nCol=3;
    int vector[3]={1,2,3};
    int resultado[3];
   
    matriz= new int*[nFilas];        //Matriz dinamica
    for(int i=0; i<nFilas; i++){
        matriz[i]=new int[nCol];
    }

    cout<<"Digite los elementos de la matriz: ";  //Agregar valores a la matriz
    for(int i=0;i<nFilas;i++){
        for(int j=0;j<nCol;j++){
            cout<<"Digite el numero "<<"["<<i<<"]"<<"["<<j<<"]: ";
            cin>>*(*(matriz+i)+j);
        }
    }


    matriz_por_vector(matriz, vector, resultado, nFilas, nCol);
   
    cout<<"El producto matriz por vector es: "<<resultado[0]<<","<<resultado[1]<<","<<resultado[2];

    for(int i=0;i<nFilas;i++){  //Borrar matriz dinamica
        delete[] matriz[i];
    }

    delete[] matriz;

    return 0;
}
        
---------------------------------------------------------------------------MATRIZ X MATRIZ------------------------------------------------------------------------------
#include <iostream>
#include <stdlib.h>
using namespace std;

void matriz_por_matriz(int** m1, int** m2, int** mf, int filas, int columnas){ //Función matriz * matriz
    for(int i=0; i<filas; i++){
        for(int j=0; j<columnas; j++){
            *(*(mf+i)+j)=(m1[i][0]*m2[0][j])+(m1[i][1]*m2[1][j])+(m1[i][2]*m2[2][j]);
        }
    }
}

int main(){
    int **matriz1, **matriz2, **matriz_final, nFilas=3, nCol=3;

    matriz1= new int*[nFilas];          //Matriz dinamica 1
    for(int i=0; i<nFilas; i++){
        matriz1[i]=new int[nCol];
    }

    matriz2= new int*[nFilas];          //Matriz dinamica 2
    for(int i=0; i<nFilas; i++){
        matriz2[i]=new int[nCol];
    }

    matriz_final= new int*[nFilas];    //Matriz dinamica final
    for(int i=0; i<nFilas; i++){
        matriz_final[i]=new int[nCol];
    }

    cout<<"Digite los elementos de la matriz 1: "<<endl;  //Agregar valores a la matriz 1
    for(int i=0;i<nFilas;i++){
        for(int j=0;j<nCol;j++){
            cout<<"Digite el numero "<<"["<<i<<"]"<<"["<<j<<"]: ";
            cin>>*(*(matriz1+i)+j);
        }
    }

    cout<<"Digite los elementos de la matriz 2: "<<endl;  //Agregar valores a la matriz 2
    for(int i=0;i<nFilas;i++){
        for(int j=0;j<nCol;j++){
            cout<<"Digite el numero "<<"["<<i<<"]"<<"["<<j<<"]: ";
            cin>>*(*(matriz2+i)+j);
        }
    }

    matriz_por_matriz(matriz1, matriz2, matriz_final, nFilas, nCol);
   
    cout<<"El producto de matrices es: "<<endl<<endl;
    for(int i=0; i<nFilas; i++){
        for(int j=0; j<nCol; j++){
            cout<<matriz_final[i][j]<<"\t";
        }
        cout<<endl;
    }

    for(int i=0;i<nFilas;i++){  //Borrar matriz dinamica 1
        delete[] matriz1[i];
    }

    for(int i=0;i<nFilas;i++){  //Borrar matriz dinamica 2
        delete[] matriz2[i];
    }

    for(int i=0;i<nFilas;i++){  //Borrar matriz dinamica final
        delete[] matriz_final[i];
    }

    delete[] matriz1;
    delete[] matriz2;
    delete[] matriz_final;

    return 0;
}

----------------------------------------------------------------------------------CLASE PUNTO--------------------------------------------------------------------------
   #include <iostream>
#include <math.h>
using namespace std; 

class Punto{
       
public:
        double x;
        double y;
        
        Punto(double x1, double y1){
        x= x1;
        y= y1;
        }
       
        Punto(){
           x=0;
           y=0;
        }
        
        double calcdist(Punto p){
        return sqrt(pow(x-p.x, 2)+pow(y-p.y, 2));
        }
        
        double calcarea(Punto p){
            double diagonal=calcdist(p);
            double area=(pow(diagonal, 2)/2);
            return area;
        }
        
        bool contiene(Punto P){
            
        }
   };
   
int main() {
   Punto p1=Punto(2, 3);
   Punto p2=Punto(4, 5);
   cout<<"El area es: "<<p1.calcarea(p2);
   
    return 0;
}

-----------------------------------------------------------------------------------CLASE VECTOR------------------------------------------------------------------------
#include <iostream>
using namespace std;

class Vector1 {
    
private:
//---------------------------------------------ATRIBUTOS------------------------------------------//
    int size;
    int capacity;
    int *v;
//------------------------------------------------------------------------------------------------//

public:
 //-------------------------------------------CONSTRUCTOR-----------------------------------------//
    Vector1(int capacity1) {
        size = 0;
        capacity = capacity1;
        v = new int[capacity];
    }
//------------------------------------------------------------------------------------------------//

//------------------------------------------------METODOS-----------------------------------------//
    
    //PUSH BACK: Agrega un elemento x al final del vector. Si esta lleno, crea uno nuevo con los mismos valores y duplica el tamaño//
    
    void push_back(int x) {     
        if (size < capacity) {  //si el vector no esta lleno, inserta en el ultimo espacio
            v[size] = x;
            size++ ;
        } 
        else{                   //si esta lleno, crea un nuevo vector, pasa los valores e inserta 
            capacity*=2;
            int *v1 = new int[capacity];
            for (int i = 0; i < size; i++) {
                v1[i] = v[i];
            }
            v1[size] = x;
            size++;
            delete[] v; //Borra el vector antiguo
            v = v1;
        }
    }

    //INSERT: Agrega un elemento x en una posición i, corriendo los elementos desde la posición i hacia la derecha//
    
    bool insert_(int x, int i) {
        if (i < capacity && i >= 0){    //Si la posición es valida, inserta
            
            if(size==capacity){        //Si el vector esta lleno, crea un nuevo vector
                
                capacity*=2;
                int *v1 = new int[capacity];
                for (int i = 0; i < size; i++){    //Pasa los valores del viejo al nuevo
                    v1[i] = v[i];
                }
    
                delete[] v; //Borra el vector antiguo
                v = v1;
                
                for (int j = size; j > i; j--) {    //Inserta realizando el corrimiento
                    v[j] = v[j - 1];
                }
                v[i] = x;
                size++; //Aumentamos el tamaño 
                return true;
            }
            
            else{                               //Si no esta lleno, inserta realizando corrimiento
                for (int j = size; j > i; j--) {
                    v[j] = v[j - 1];
                }
                v[i] = x;
                size++; //Aumentamos el tamaño 
                return true;
            }
        }
        else{               //Si la posición no es valida, no hace nada
            return false;
        }
    }

    //REMOVE: Elimina el valor que este en la posición i, corriendo los demás valores a la izquierda para no dejar huecos//
    
    bool remove_(int i) {
        if (i < capacity && i >= 0) {   //Pone el valor de la derecha del que queremos eliminar 
            for (int j = i; j < size-1; j++) {
                v[j] = v[j + 1];
            }
            size--; //Quitamos del tamaño al elemento eliminado
            return true;
        }
        else {           //Si la posición no es valida, no hace nada
            return false;
        }
    }

    //GET: Retorna el valor de la posición i en el vector//
    
    int get(int i) {
        if(i<capacity && i >= 0){
        return v[i];
        }
        else{
            cout<<"Posición erronea";
        }
    }

    //SET: Inserta el valor x en la posición i sin realizar corrimiento//
    
    void set(int x, int i) {
        if (i < capacity && i >= 0) {
            v[i] = x;
        }
        else{
            cout<<"Posición erronea";
        }
    }
    
    //PRINT: Muestra los valores del vector//
    
    void print() {
        for (int i = 0; i <size; i++) {
            cout << v[i] << "\t";
        }
        cout<<endl;
    }
    
    //ATRIBUTOS: Muestra los atributos del vector//
    
    void atributos(){
        cout <<"La capacidad del vector es: " <<capacity<<endl;
        cout <<"la cantidad de elementos es: " <<size<<endl;
    } 
//------------------------------------------------------------------------------------------------//
};

int main(){
    Vector1 p = Vector1(1);
    p.atributos();
    
//------------------------------------------PRUEBA PUSH BACK--------------------------------------//
    
    cout<<"---------------------------------------------"<<endl;
    p.push_back(5);
    p.print();
    cout<<"---------------------------------------------"<<endl;
    p.atributos();
    cout<<"---------------------------------------------"<<endl;

    p.push_back(13);
    p.print();
    cout<<"---------------------------------------------"<<endl;
    p.atributos();
    cout<<"---------------------------------------------"<<endl;
    
//------------------------------------------------------------------------------------------------//

//-------------------------------------------PRUEBA INSERT----------------------------------------//
    
    p.insert_(7, 1);
    p.print();
    cout<<"---------------------------------------------"<<endl;
    p.atributos();
    cout<<"---------------------------------------------"<<endl;
    
    p.insert_(9, 2);
    p.print();
    cout<<"---------------------------------------------"<<endl;
    p.atributos();
    cout<<"---------------------------------------------"<<endl;
    
    p.insert_(11, 3);
    p.print();
    cout<<"---------------------------------------------"<<endl;
    p.atributos();
    cout<<"---------------------------------------------"<<endl;
    
    p.insert_(2, 2);
    p.print();
    cout<<"---------------------------------------------"<<endl;
    p.atributos();
    cout<<"---------------------------------------------"<<endl;

//------------------------------------------------------------------------------------------------//

//------------------------------------------PRUEBA REMOVE-----------------------------------------//
    
    p.remove_(2);
    p.print();
    cout<<"---------------------------------------------"<<endl;
    p.atributos();
    cout<<"---------------------------------------------"<<endl;

//------------------------------------------------------------------------------------------------//

//--------------------------------------------PRUEBA GET------------------------------------------//

    cout<<"La posición 2 tiene el valor: "<<p.get(2)<<endl;
    cout<<"---------------------------------------------"<<endl;
    
//------------------------------------------------------------------------------------------------//

//--------------------------------------------PRUEBA SET------------------------------------------//
    
    p.set(15, 0);
    p.print();
    cout<<"---------------------------------------------"<<endl;
    p.atributos();
    cout<<"---------------------------------------------"<<endl;

//------------------------------------------------------------------------------------------------//
    return 0;
}
        
-----------------------------------------------------------------LISTAS ENLAZADAS (CLASE PUNTO)------------------------------------------------------------------------
    #include<iostream>
#include <math.h> 

using namespace std;

class Point {

//Atributos
    int x;
    int y;

    const int rmax = 1;

public:
    
    //Constructores
    Point(int xc, int yc) {
        x = xc;
        y = yc;

    }

    Point() {
        x = 0;
        y = 0;
    }

    //M�todos
    
    Point ofuscacion() {
        return Point(x + 2 * (rand() % rmax) - rmax, y + 2 * (rand() % rmax) - rmax);
    }
    
    double dist() {
        return dist(0,0);
    }

    double dist(int xc, int yc) {
        return sqrt(pow(x-xc, 2) + pow(y-yc, 2));
    }

    double dist(Point p) {
        return dist(p.x, p.y);
    }

    //Getters
    int getX() {
        return x;
    }

    int getY() {
        return y;
    }


    //Setters
    void setX(int xc) {
        x = xc;
    }

    void setY(int yc) {
        y = yc;
    }
    
    Point& operator=(const Point& f) { 
		setX(f.x);
		setY(f.y);
		return *this; 
	}
	
	string to_string() {
		return "("+std::to_string(x) + "," + std::to_string(y)+")";
	}


	friend std::ostream& operator<<(std::ostream& os, Point& b) {
		return os << b.to_string();
	}

};

class Nodo{
  
  Point* dato;
  Nodo* pointer;
  
public:
  
  Nodo(){
      dato = NULL;
      pointer = NULL;
  }
  
  ~Nodo(){
      delete dato;
  }
  
  Nodo(Point* d){
      dato = d;
      pointer = NULL;
  }
    
  Point* getDato(){
      return dato;
  }
  
  void setDato(Point* d){
      dato = d;
  }
  
  Nodo* getNext(){
      return pointer;
  }
  
  void setNext(Nodo* p){
      pointer = p;
  }
    
    string to_string() {
		return getDato()->to_string();
	}


	friend std::ostream& operator<<(std::ostream& os, Nodo& b) {
		return os << b.to_string();
	}
    
};

class Lista{
    
    Nodo* ptr;
    int size;

public:  

    Lista(){
        ptr = NULL;
        size = 0;
    }
    
    ~Lista(){
        Nodo* t = ptr;
        Nodo* n;
        while(t->getNext() != NULL){
            n = t;
            t = t->getNext();    
            delete n;
        }
        delete t;
    }
    
    void push_back(Point* d){
        
        if(size == 0){
            ptr = new Nodo(d);
            size++;
        }else{
            Nodo* t = ptr;
            while(t->getNext() != NULL){
                t = t->getNext();    
            }
            t->setNext(new Nodo(d));
            size++;
        }
        
    }
    
    int getSize(){
        return size;
    }
    
    void print(){
        if(size == 0){
            cout<<"La lista está vacía"<<endl;
        }else{
            Nodo* t = ptr;
            do{
                //cout<<"("<<(*t).getDato()->getX()<<", "<<t->getDato()->getY()<<"), ";
                cout<<(*t)<<", ";
                t = t->getNext();
                
            }while(t != NULL);
            cout<<endl;
        }
    }
    
    Nodo* get(int i){
        if(i < size && i>=0){
            Nodo* n = ptr;
            for(int x = 0; x<i;x++){
                n = n->getNext();
            }
            return n;
        }else{
            //throw invalid_argument("La posicion no existe");
            if(size == 0){
                cout<<"La lista está vacía";
            }else{
                cout<<"La posicion no existe";
            }
            return NULL;
        }
        
    }
    
    void insert(Point* p, int pos){
        if(pos >= 0 && pos <= size){
            //Si la lista está vacía o si se quiere insertar el nodo al final
            //se usa el método push_back
            if(size == 0 || pos == size){ 
                push_back(p);
            }else{
                Nodo* n = new Nodo(p);
                //Si se quiere insertar el nodo de primero en la lista
                if(pos == 0){
                    n->setNext(ptr);
                    ptr = n;
                }else{
                    Nodo* t = get(pos-1);
                    n->setNext(t->getNext());
                    t->setNext(n);
                }
                size++;
            }
        }else{
            throw invalid_argument("La posicion no existe");
        }
        
    }
    
    void remove(int pos){
        if(pos >= 0 && pos <size){
            if(size == 0){
                cout<<"La lista no tiene elementos";
            }else{
                if(pos==0){
                    Nodo* n=ptr;
                    ptr=ptr->getNext();
                    delete n;
                    size--;
                }else{
                    Nodo* n=get(pos-1);
                    Nodo* t=get(pos);
                    n->setNext(t->getNext());
                    delete t;
                    size--;
                }
            }
        }else{
            cout<<"La posición no existe";
        }
    }
    
    void atributos(){
        cout <<"la cantidad de elementos es: " <<size<<endl;
    } 
};


int main(){
   
    Lista l = Lista();
   
    l.push_back(new Point(1,1));
   
    l.print();
   
    l.push_back(new Point(2,2));
   
    l.print();
   
    for(int i = 3; i<10; i++){
        l.push_back(new Point(i,i));
    }
   
    l.print();
   
    cout<<(*l.get(2)->getDato())<<endl;
    cout<<(*l.get(2))<<endl;
   
    l.insert(new Point(20,20),5);
   
    l.print();
    cout<<"-----------------------------------------"<<endl;
    Lista l2 = Lista();
   
    l2.insert(new Point(20,20),0);
    l2.insert(new Point(21,21),1);
    l2.insert(new Point(22,22),2);
    l2.insert(new Point(23,23),3);
    l2.insert(new Point(24,24),4);
    l2.insert(new Point(25,25),5);
   
    l2.print();
    l2.atributos();
    l2.remove(0);
    l2.print();
    l2.atributos();
   
    return 0;
}
